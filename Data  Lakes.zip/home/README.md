Project Purpose :
     In pervious project i have load the data to data warehouse in this project im moving the data from data ware house to data lake. i created a ETL pipeline that extracts data from AWS S3,to process the data into analytics tables using from Spark.
     
DATA BASE SCHEMA :
      For read data from s3 song_data and log_data have given.
      FACT TABLE:
           songplays: - records in log data associated with song plays i.e. records with page NextSong
           Columns will be ongplay_id, start_time, user_id, level, song_id, artist_id, session_id, location, user_agent
      DIMENSION TABLE:
          1.users: - users in the app
            Columns will be user_id, first_name, last_name, gender, level
          2.songs: - songs in music database
            Columns will be song_id, title, artist_id, year, duration
          3.artists: - artists in music database
             Columns will be artist_id, name, location, latitude, longitude
          4.time: - timestamps of records in songplays broken down into specific units
             Columns will be start_time, hour, day, week, month, year, weekday
       partitioned parquet files are written to load back the data to s3